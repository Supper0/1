/* eslint-disable */
export const root = require('./root.png');
export const safely_harvest_honey = require('./safely_harvest_honey.png');
export const breed_an_animal = require('./breed_an_animal.png');
export const tame_an_animal = require('./tame_an_animal.png');
export const fishy_business = require('./fishy_business.png');
export const silk_touch_nest = require('./silk_touch_nest.png');
export const plant_seed = require('./plant_seed.png');
export const bred_all_animals = require('./bred_all_animals.png');
export const complete_catalogue = require('./complete_catalogue.png');
export const tactical_fishing = require('./tactical_fishing.png');
export const balanced_diet = require('./balanced_diet.png');
export const break_diamond_hoe = require('./break_diamond_hoe.png');
