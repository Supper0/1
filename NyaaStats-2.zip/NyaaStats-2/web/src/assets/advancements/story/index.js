/* eslint-disable */
export const root = require('./root.png');
export const mine_stone = require('./mine_stone.png');
export const upgrade_tools = require('./upgrade_tools.png');
export const smelt_iron = require('./smelt_iron.png');
export const obtain_armor = require('./obtain_armor.png');
export const lava_bucket = require('./lava_bucket.png');
export const iron_tools = require('./iron_tools.png');
export const deflect_arrow = require('./deflect_arrow.png');
export const form_obsidian = require('./form_obsidian.png');
export const mine_diamond = require('./mine_diamond.png');
export const enter_the_nether = require('./enter_the_nether.png');
export const shiny_gear = require('./shiny_gear.png');
export const enchant_item = require('./enchant_item.png');
export const cure_zombie_villager = require('./cure_zombie_villager.png');
export const follow_ender_eye = require('./follow_ender_eye.png');
export const enter_the_end = require('./enter_the_end.png');
