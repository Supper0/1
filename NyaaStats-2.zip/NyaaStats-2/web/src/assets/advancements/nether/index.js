/* eslint-disable */
export const root = require('./root.png');
export const return_to_sender = require('./return_to_sender.png');
export const fast_travel = require('./fast_travel.png');
export const find_fortress = require('./find_fortress.png');
export const uneasy_alliance = require('./uneasy_alliance.png');
export const get_wither_skull = require('./get_wither_skull.png');
export const obtain_blaze_rod = require('./obtain_blaze_rod.png');
export const summon_wither = require('./summon_wither.png');
export const brew_potion = require('./brew_potion.png');
export const create_beacon = require('./create_beacon.png');
export const all_potions = require('./all_potions.png');
export const create_full_beacon = require('./create_full_beacon.png');
export const all_effects = require('./all_effects.png');
