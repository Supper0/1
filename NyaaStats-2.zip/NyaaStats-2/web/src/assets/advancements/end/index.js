/* eslint-disable */
export const root = require('./root.png');
export const kill_dragon = require('./kill_dragon.png');
export const dragon_egg = require('./dragon_egg.png');
export const enter_end_gateway = require('./enter_end_gateway.png');
export const respawn_dragon = require('./respawn_dragon.png');
export const dragon_breath = require('./dragon_breath.png');
export const find_end_city = require('./find_end_city.png');
export const elytra = require('./elytra.png');
export const levitate = require('./levitate.png');
